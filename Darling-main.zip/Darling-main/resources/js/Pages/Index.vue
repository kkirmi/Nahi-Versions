<template>

</template>

<script>

export default {
    props:{
    },
    data(){
        return{
        }
    },
    beforeMount(){
    },
    methods:{
    },
}
</script>